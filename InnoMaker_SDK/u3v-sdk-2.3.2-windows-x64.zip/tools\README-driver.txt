U3V Camera Driver Installation (WinUSB via Zadig)
====================================================

This folder contains Zadig 2.9, the third-party tool used to install
the WinUSB driver on the U3V camera.

QUICK START
-----------
1. Plug in the U3V camera (any USB 3.0 port).
2. Right-click "zadig-2.9.exe" -> Run as administrator.
3. In Zadig:
   - Menu: Options -> List All Devices (check this on)
   - Top dropdown: select the camera's "Composite Parent" device
     (usually shows as "USB Composite Device" or model name)
   - Driver column: select "WinUSB (vX.Y.Z.Z)"
   - Click "Replace Driver"
4. Wait ~30 seconds until Zadig confirms success.
5. Re-plug the camera once. The U3V SDK should now enumerate it.

DETAILED GUIDE
--------------
See ../WINUSB_DRIVER_INSTALL.md in the parent folder for screenshots
and troubleshooting.

ABOUT ZADIG
-----------
Zadig is open-source (GPLv3) software by Pete Batard / Akeo Consulting.
It is bundled here for convenience. The original project and source
code are available at:

    https://zadig.akeo.ie/
    https://github.com/pbatard/libwdi

Zadig is licensed under the GNU General Public License version 3.
See LICENSE-zadig.txt in this folder for the full license text.

SUPPORT
-------
If Zadig fails to install the driver:
- Make sure you ran it as Administrator (right-click -> Run as administrator)
- Try unplugging the camera and plugging it back in before retrying
- On some systems, Windows Update may auto-replace the driver after
  a reboot. If this happens, run Zadig again.
