﻿U3V Camera SDK 2.3.2 — Windows x64
=====================================

Layout
------
  bin/                        u3v_viewer.exe and everything it needs at runtime
  bin/plugins/                Official ISP plugins (u3v_isp_color, u3v_ccm, u3v_gamma)
  lib/                        u3v_cam.lib — import library for MSVC link
  include/u3v/                Public SDK headers (#include <u3v/u3v_sdk.h>)
  examples/                   basic_capture — minimal CLI capture example
                              multi_frame_capture — MultiFrame N-frame acquisition example
  tools/                      WinUSB driver installer (Zadig 2.9)
  WINUSB_DRIVER_INSTALL.md    Driver installation guide (READ FIRST on new machines)
  docs/                       RELEASE_NOTES.md

First-time driver install
-------------------------
  Read WINUSB_DRIVER_INSTALL.md, then run tools\zadig-2.9.exe as
  Administrator to install the WinUSB driver on your U3V camera.
  Required once per Windows machine before the SDK can enumerate the
  device.

Quick start (viewer)
--------------------
  bin\u3v_viewer.exe
  Connect -> select camera -> Preview.
  Color IMX296 users: unfold the "Color / ISP" section for demosaic /
  white-balance / gamma / CCM controls.

Quick start (SDK link)
----------------------
  MSVC command line:
    cl your_app.c /I "path\to\include" "path\to\lib\u3v_cam.lib"
  Deploy u3v_cam.dll + libusb-1.0.dll next to your .exe.

See docs\RELEASE_NOTES.md for this version's release notes.
