/**
 * u3v_sensors.h - Per-sensor regmap initialization + VID/PID dispatch
 *
 * Each supported sensor / camera family provides an init function that
 * populates u3v_regmap_t with that sensor's register addresses. A static
 * dispatch table maps (VID, PID) to the appropriate init function so
 * u3v_camera_open() can pick the right map without an if-else chain.
 *
 * Adding a new sensor:
 *   1. Add a u3v_regmap_init_<sensor>() function in u3v_sensors.c.
 *   2. Append a row to SENSOR_TABLE in u3v_sensors.c.
 *   3. Confirm with the u3v_probe internal tool that addresses match.
 */
#ifndef U3V_SENSORS_H
#define U3V_SENSORS_H

#include "u3v_camera.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ---- Per-sensor regmap initializers ---- */

/* Sony IMX296 (global-shutter, 1456x1088). Used by InnoMaker U3V1456-60GM
 * and any Cypress-FX3 firmware sharing the same register layout. */
void u3v_regmap_init_imx296(u3v_regmap_t *regmap);

/* OmniVision OV9281 (global-shutter, 1280x800). Used by InnoMaker
 * U3V1280-144GM. Currently shares the IMX296 register layout — verified
 * 2026-05-11 by u3v_probe on both production samples. Function exists as
 * a separate symbol so future divergence is a single-file change. */
void u3v_regmap_init_ov9281(u3v_regmap_t *regmap);

/* Basler USB3 Vision cameras (Pylon-flavored register map, addresses
 * derived from the GenICam XML). */
void u3v_regmap_init_basler(u3v_regmap_t *regmap);

/* Generic fallback: all fields zeroed. SDK relies on GenICam XML discovery
 * to populate addresses at runtime for unknown cameras. If XML discovery
 * also fails, the camera will not be operable through the SDK's typed
 * accessors. */
void u3v_regmap_init_defaults(u3v_regmap_t *regmap);

/* ---- VID/PID dispatch table ---- */

typedef struct {
    uint16_t     vid;            /* USB vendor ID */
    uint16_t     pid;            /* USB product ID; 0 = wildcard within this VID */
    const char  *name;           /* human-readable label (logged at camera open) */
    void       (*init_regmap)(u3v_regmap_t *);
} u3v_sensor_entry_t;

/* Look up the best matching sensor entry for a (vid, pid) tuple.
 *
 * Match priority:
 *   1. exact (VID, PID)
 *   2. VID match with PID == 0 (wildcard within a vendor)
 *   3. catch-all entry (VID == 0, PID == 0)
 *
 * The stock SENSOR_TABLE always contains a catch-all, so the function
 * returns non-NULL in normal operation. Callers should still null-check
 * defensively in case the table is customized. */
const u3v_sensor_entry_t *u3v_sensor_lookup(uint16_t vid, uint16_t pid);

#ifdef __cplusplus
}
#endif

#endif /* U3V_SENSORS_H */
