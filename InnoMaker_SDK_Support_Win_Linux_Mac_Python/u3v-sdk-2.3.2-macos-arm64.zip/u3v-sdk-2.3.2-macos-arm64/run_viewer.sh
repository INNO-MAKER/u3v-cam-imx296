#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
open "$DIR/bin/u3v_viewer.app"
