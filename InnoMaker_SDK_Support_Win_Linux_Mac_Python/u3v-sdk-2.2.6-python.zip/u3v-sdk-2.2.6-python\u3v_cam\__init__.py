"""USB3 Vision camera SDK — Python interface.

Quick start::

    import u3v_cam

    with u3v_cam.Camera() as cam:
        cam.exposure_us = 5000
        cam.gain = 0
        cam.start()
        for _ in range(60):
            frame = cam.read_frame()      # numpy.ndarray (h, w) uint8 for Mono8
            ...
        cam.stop()
"""
from __future__ import annotations

import atexit
import ctypes
import threading
from contextlib import suppress
from typing import Any, Dict, List, Optional

import numpy as np

from . import _raw as r
from ._loader import plugin_dir as _default_plugin_dir

__version__ = "2.2.6"


# --------------------------------------------------------------------------
# Exception type
# --------------------------------------------------------------------------
class U3VError(RuntimeError):
    """SDK-level error.  ``code`` is the underlying ``u3v_status_t``."""

    def __init__(self, code: int, where: str = ""):
        self.code = int(code)
        msg = r.status_str(self.code)
        if where:
            msg = f"{where}: {msg}"
        super().__init__(f"{msg} (code={self.code})")


class U3VIncompleteFrame(U3VError):
    """Raised by :meth:`Camera.read_frame` when the SDK returns a torn or short
    frame (``U3V_ERR_INCOMPLETE``): the image data is unreliable and should be
    dropped rather than used. Subclasses :class:`U3VError`, so existing
    ``except U3VError`` handlers still catch it. Iterating a camera
    (``for frame in cam``) skips these frames automatically."""


def _check(code: int, where: str = "") -> None:
    if code != r.U3V_OK:
        raise U3VError(code, where)


# --------------------------------------------------------------------------
# SDK singleton init / shutdown
# --------------------------------------------------------------------------
_sdk_lock = threading.Lock()
_sdk_inited = False


def _sdk_ensure_init() -> None:
    global _sdk_inited
    with _sdk_lock:
        if _sdk_inited:
            return
        _check(r.sdk_init(), "u3v_sdk_init")
        _sdk_inited = True
        atexit.register(_sdk_at_exit)


def _sdk_at_exit() -> None:
    global _sdk_inited
    with _sdk_lock:
        if _sdk_inited:
            with suppress(Exception):
                r.sdk_shutdown()
            _sdk_inited = False


# --------------------------------------------------------------------------
# Discovery
# --------------------------------------------------------------------------
def list_cameras(max_devices: int = 8) -> List[Dict[str, Any]]:
    """Return a list of visible USB3 Vision cameras."""
    _sdk_ensure_init()
    arr = (r.u3v_device_info_t * max_devices)()
    count = r.discover(arr, max_devices)
    out: List[Dict[str, Any]] = []
    for i in range(count):
        d = arr[i]
        out.append({
            "index":        d.device_index,
            "vendor_id":    d.vendor_id,
            "product_id":   d.product_id,
            "manufacturer": d.manufacturer.decode(errors="replace").strip("\x00"),
            "model":        d.model.decode(errors="replace").strip("\x00"),
            "serial":       d.serial.decode(errors="replace").strip("\x00"),
        })
    return out


# --------------------------------------------------------------------------
# Pixel format helper
# --------------------------------------------------------------------------
def _frame_to_array(buf: r.u3v_buffer_t) -> np.ndarray:
    """One-copy view of buffer.data into a numpy array shaped to the frame."""
    size = int(buf.received_size) or int(buf.size)
    if size == 0 or not buf.data:
        return np.empty(0, dtype=np.uint8)

    raw = ctypes.string_at(buf.data, size)
    pf = int(buf.pixel_format)
    w, h = int(buf.width), int(buf.height)
    bpp = r.PFNC_BPP.get(pf, 8)

    if bpp == 8:
        arr = np.frombuffer(raw, dtype=np.uint8)
        if h and w and arr.size >= h * w:
            return arr[:h * w].reshape(h, w)
        return arr
    if bpp == 16:
        arr = np.frombuffer(raw, dtype=np.uint16)
        if h and w and arr.size >= h * w:
            return arr[:h * w].reshape(h, w)
        return arr
    if bpp == 24:
        arr = np.frombuffer(raw, dtype=np.uint8)
        if h and w and arr.size >= h * w * 3:
            return arr[:h * w * 3].reshape(h, w, 3)
        return arr
    return np.frombuffer(raw, dtype=np.uint8)


# --------------------------------------------------------------------------
# Camera class
# --------------------------------------------------------------------------
class Camera:
    """High-level handle for a single USB3 Vision camera."""

    def __init__(self, index: int = 0,
                 num_buffers: int = 4,
                 timeout_ms: int = 5000,
                 transfer_size: int = 0):
        _sdk_ensure_init()

        self._handle = r.u3v_camera_p()
        _check(r.camera_open(ctypes.byref(self._handle), int(index)),
               "u3v_camera_open")

        self._stream: Optional[r.u3v_stream_p] = None
        self._buf: Optional[r.u3v_buffer_t] = None
        self._pipeline: Optional[r.u3v_pipeline_p] = None
        self._view: Optional[r.u3v_buffer_t] = None
        self._streaming = False
        self._acq_mode_touched = False
        self._stream_cfg = r.u3v_stream_config_t(
            num_buffers=int(num_buffers),
            timeout_ms=int(timeout_ms),
            transfer_size=int(transfer_size),
        )

    # ---- context manager ----
    def __enter__(self) -> "Camera":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    # ---- info / device ----
    @property
    def info(self) -> Dict[str, Any]:
        ptr = r.camera_get_info(self._handle)
        if not ptr:
            raise U3VError(r.U3V_ERR_NOT_CONNECTED, "camera_get_info")
        i = ptr.contents
        return {
            "manufacturer":     i.manufacturer.decode(errors="replace").strip("\x00"),
            "model":            i.model.decode(errors="replace").strip("\x00"),
            "serial":           i.serial.decode(errors="replace").strip("\x00"),
            "firmware_version": i.firmware_version.decode(errors="replace").strip("\x00"),
            "sensor_width":     int(i.sensor_width),
            "sensor_height":    int(i.sensor_height),
            "width_max":        int(i.width_max),
            "height_max":       int(i.height_max),
        }

    # ---- ROI / format ----
    def _get_u32(self, fn) -> int:
        v = ctypes.c_uint32(0)
        _check(fn(self._handle, ctypes.byref(v)), fn.__name__)
        return int(v.value)

    @property
    def width(self) -> int:        return self._get_u32(r.camera_get_width)
    @width.setter
    def width(self, v: int) -> None: _check(r.camera_set_width(self._handle, int(v)), "set_width")

    @property
    def height(self) -> int:       return self._get_u32(r.camera_get_height)
    @height.setter
    def height(self, v: int) -> None: _check(r.camera_set_height(self._handle, int(v)), "set_height")

    @property
    def offset_x(self) -> int:     return self._get_u32(r.camera_get_offset_x)
    @offset_x.setter
    def offset_x(self, v: int) -> None: _check(r.camera_set_offset_x(self._handle, int(v)), "set_offset_x")

    @property
    def offset_y(self) -> int:     return self._get_u32(r.camera_get_offset_y)
    @offset_y.setter
    def offset_y(self, v: int) -> None: _check(r.camera_set_offset_y(self._handle, int(v)), "set_offset_y")

    @property
    def pixel_format(self) -> int: return self._get_u32(r.camera_get_pixel_format)
    @pixel_format.setter
    def pixel_format(self, v: int) -> None: _check(r.camera_set_pixel_format(self._handle, int(v)), "set_pixel_format")

    @property
    def payload_size(self) -> int: return self._get_u32(r.camera_get_payload_size)

    def set_roi(self, width: int, height: int,
                offset_x: int = 0, offset_y: int = 0) -> None:
        """Set ROI in one go.  Order matters on some firmwares."""
        self.offset_x = 0
        self.offset_y = 0
        self.width = width
        self.height = height
        self.offset_x = offset_x
        self.offset_y = offset_y

    # ---- exposure / gain / framerate ----
    @property
    def exposure_us(self) -> int:  return self._get_u32(r.camera_get_exposure)
    @exposure_us.setter
    def exposure_us(self, v: int) -> None: _check(r.camera_set_exposure(self._handle, int(v)), "set_exposure")

    def set_exposure_auto(self, enable: bool) -> None:
        _check(r.camera_set_exposure_auto(self._handle, 1 if enable else 0),
               "set_exposure_auto")

    def get_exposure_auto(self) -> int:
        """Current ExposureAuto mode: 0=Off, 1=Once, 2=Continuous."""
        return self._get_u32(r.camera_get_exposure_auto)

    @property
    def gain(self) -> int:         return self._get_u32(r.camera_get_gain)
    @gain.setter
    def gain(self, v: int) -> None: _check(r.camera_set_gain(self._handle, int(v)), "set_gain")

    @property
    def frame_rate(self) -> int:   return self._get_u32(r.camera_get_frame_rate)
    @frame_rate.setter
    def frame_rate(self, v: int) -> None: _check(r.camera_set_frame_rate(self._handle, int(v)), "set_frame_rate")

    @property
    def frame_count(self) -> int:
        """Frames to acquire when acquisition mode is MultiFrame."""
        return self._get_u32(r.camera_get_frame_count)
    @frame_count.setter
    def frame_count(self, v: int) -> None:
        _check(r.camera_set_frame_count(self._handle, int(v)), "set_frame_count")

    def set_acq_mode(self, mode: int) -> None:
        """Set acquisition mode: ACQ_MODE_CONTINUOUS / SINGLE_FRAME / MULTI_FRAME."""
        _check(r.camera_set_acq_mode(self._handle, int(mode)), "set_acq_mode")
        self._acq_mode_touched = True

    # ---- trigger ----
    @property
    def trigger_mode(self) -> bool:
        return bool(self._get_u32(r.camera_get_trigger_mode))

    @trigger_mode.setter
    def trigger_mode(self, on: bool) -> None:
        _check(r.camera_set_trigger_mode(self._handle, 1 if on else 0), "set_trigger_mode")

    @property
    def trigger_source(self) -> int:
        return self._get_u32(r.camera_get_trigger_source)

    @trigger_source.setter
    def trigger_source(self, src: int) -> None:
        _check(r.camera_set_trigger_source(self._handle, int(src)), "set_trigger_source")

    @property
    def trigger_activation(self) -> int:
        """Trigger edge: 2=FallingEdge, 3=RisingEdge."""
        return self._get_u32(r.camera_get_trigger_activation)

    @trigger_activation.setter
    def trigger_activation(self, act: int) -> None:
        _check(r.camera_set_trigger_activation(self._handle, int(act)), "set_trigger_activation")

    def configure_trigger(self,
                          on: bool = True,
                          source: str = "software",
                          activation: str = "rising",
                          selector: str = "frame_start") -> None:
        """Convenience: configure trigger before ``start()``.

        ``source`` ∈ {"line0".."line3", "software"}
        ``activation`` ∈ {"rising", "falling"}
        ``selector`` ∈ {"frame_start", "acq_start"}
        """
        sel_map = {
            "frame_start": r.IMX296_TRIGGER_SEL_FRAME_START,
            "acq_start":   r.IMX296_TRIGGER_SEL_ACQ_START,
        }
        src_map = {
            "line0":    r.IMX296_TRIGGER_SRC_LINE0,
            "line1":    r.IMX296_TRIGGER_SRC_LINE1,
            "line2":    r.IMX296_TRIGGER_SRC_LINE2,
            "line3":    r.IMX296_TRIGGER_SRC_LINE3,
            "software": r.IMX296_TRIGGER_SRC_SOFTWARE,
        }
        act_map = {
            "rising":  r.IMX296_TRIGGER_ACT_RISING_EDGE,
            "falling": r.IMX296_TRIGGER_ACT_FALLING_EDGE,
        }
        if selector not in sel_map:    raise ValueError(f"selector: {selector}")
        if source   not in src_map:    raise ValueError(f"source: {source}")
        if activation not in act_map:  raise ValueError(f"activation: {activation}")

        _check(r.camera_set_trigger_selector(self._handle, sel_map[selector]),  "set_trigger_selector")
        _check(r.camera_set_trigger_mode(self._handle, 1 if on else 0),         "set_trigger_mode")
        _check(r.camera_set_trigger_source(self._handle, src_map[source]),      "set_trigger_source")
        _check(r.camera_set_trigger_activation(self._handle, act_map[activation]), "set_trigger_activation")

    def software_trigger(self) -> None:
        _check(r.camera_send_software_trigger(self._handle), "send_software_trigger")

    def set_line_debounce_us(self, us: int) -> None:
        _check(r.camera_set_line_debounce(self._handle, int(us)), "set_line_debounce")

    def get_line_debounce_us(self) -> int:
        return self._get_u32(r.camera_get_line_debounce)

    def set_strobe(self, duration_us: int, delay_us: int = 0,
                   pre_delay_us: int = 0) -> None:
        _check(r.camera_set_strobe(self._handle, int(duration_us),
                                   int(delay_us), int(pre_delay_us)),
               "set_strobe")

    def get_strobe(self) -> tuple:
        """Return current strobe timing as (duration_us, delay_us, pre_delay_us)."""
        duration = ctypes.c_uint32(0)
        delay = ctypes.c_uint32(0)
        pre_delay = ctypes.c_uint32(0)
        _check(r.camera_get_strobe(self._handle, ctypes.byref(duration),
                                   ctypes.byref(delay), ctypes.byref(pre_delay)),
               "get_strobe")
        return (int(duration.value), int(delay.value), int(pre_delay.value))

    # ---- misc ----
    @property
    def temperature(self) -> int:
        """Sensor temperature, raw register units."""
        return self._get_u32(r.camera_get_temperature)

    def find_me_led(self, on: bool = True) -> None:
        """Toggle the find-me indicator LED.  SDK call alternates state."""
        _check(r.camera_find_me(self._handle), "find_me")

    def reset(self) -> None:
        _check(r.camera_reset(self._handle), "camera_reset")

    def flush(self) -> None:
        r.camera_flush_stream(self._handle)

    # ---- raw register access (escape hatch) ----
    def read_register(self, address: int) -> int:
        v = ctypes.c_uint32(0)
        _check(r.camera_read_reg(self._handle, int(address), ctypes.byref(v)),
               f"read_reg(0x{address:08X})")
        return int(v.value)

    def write_register(self, address: int, value: int) -> None:
        _check(r.camera_write_reg(self._handle, int(address), int(value)),
               f"write_reg(0x{address:08X})")

    # ---- streaming ----
    def _ensure_stream(self) -> None:
        if self._stream is not None:
            return

        # set acquisition mode to continuous unless the caller already touched it
        if not self._acq_mode_touched:
            with suppress(U3VError):
                r.camera_set_acq_mode(self._handle, r.IMX296_ACQ_MODE_CONTINUOUS)

        s = r.u3v_stream_p()
        _check(r.stream_create(ctypes.byref(s), self._handle,
                               ctypes.byref(self._stream_cfg)),
               "stream_create")
        self._stream = s

        # If a color pipeline was requested before the stream existed, attach
        # it now so read_frame() routes through the ISP (grab_view) path.
        if self._pipeline is not None:
            _check(r.stream_set_pipeline(self._stream, self._pipeline),
                   "stream_set_pipeline")

        size = self.payload_size or (self.width * self.height) or (1456 * 1088)
        buf = r.u3v_buffer_t()
        _check(r.buffer_alloc(ctypes.byref(buf), int(size)), "buffer_alloc")
        self._buf = buf

    def start(self) -> None:
        if self._streaming:
            return
        self._ensure_stream()
        _check(r.camera_start(self._handle), "camera_start")
        self._streaming = True

    def stop(self) -> None:
        if not self._streaming:
            return
        with suppress(Exception):
            r.camera_stop(self._handle)
        self._streaming = False

    # ---- color / ISP pipeline ----
    def enable_color(self, plugin_dir: Optional[str] = None) -> int:
        """Enable the ISP pipeline so color frames come back demosaiced.

        Loads the demosaic (+ optional white balance / gamma / CCM) plugins
        that ship next to the native library and attaches them to the stream —
        the same path the Qt viewer uses. After this, ``read_frame()`` returns
        an ``(H, W, 3)`` RGB8 array for Bayer color sensors instead of the raw
        single-channel mosaic.

        ``plugin_dir`` overrides the auto-detected plugin folder. Returns the
        number of plugins loaded. Raises ``FileNotFoundError`` if no plugins
        are found. Mono sensors are unaffected — the plugins pass non-Bayer
        frames through unchanged. Call before or after ``start()``.
        """
        if self._pipeline is not None:
            return int(r.pipeline_plugin_count(self._pipeline))

        directory = plugin_dir if plugin_dir is not None else _default_plugin_dir()
        if not directory:
            raise FileNotFoundError(
                "No ISP plugin directory found. Pass plugin_dir=..., set "
                "U3V_PLUGIN_DIR, or place the plugins under "
                "u3v_cam/_libs/<platform>/plugins/."
            )

        pipe = r.u3v_pipeline_p()
        _check(r.pipeline_create(ctypes.byref(pipe)), "pipeline_create")
        r.pipeline_load_dir(pipe, directory.encode())
        count = int(r.pipeline_plugin_count(pipe))
        if count == 0:
            r.pipeline_destroy(pipe)
            raise FileNotFoundError(
                f"No ISP plugins loaded from {directory!r}. Color demosaic is "
                "unavailable; check that the plugins/ folder shipped with this "
                "package."
            )

        self._pipeline = pipe
        self._view = r.u3v_buffer_t()
        if self._stream is not None:
            _check(r.stream_set_pipeline(self._stream, self._pipeline),
                   "stream_set_pipeline")
        return count

    def disable_color(self) -> None:
        """Detach and destroy the ISP pipeline; frames revert to raw grab."""
        if self._stream is not None and self._pipeline is not None:
            with suppress(Exception):
                r.stream_set_pipeline(self._stream, None)
        if self._pipeline is not None:
            with suppress(Exception):
                r.pipeline_destroy(self._pipeline)
            self._pipeline = None
        self._view = None

    @property
    def color_enabled(self) -> bool:
        """True if the ISP demosaic pipeline is active."""
        return self._pipeline is not None

    def read_frame(self, copy: bool = True) -> np.ndarray:
        """Grab a single frame.

        ``copy=True`` (default) returns a NumPy array that owns its memory.
        ``copy=False`` returns a view into the SDK's reusable buffer — only
        valid until the next ``read_frame`` call.

        Shape is ``(H, W)`` for Mono / raw Bayer, or ``(H, W, 3)`` RGB8 when
        the color pipeline is enabled (see :meth:`enable_color`).
        """
        if not self._streaming:
            self.start()
        assert self._stream is not None
        if self._pipeline is not None:
            assert self._view is not None
            code = r.stream_grab_view(self._stream, ctypes.byref(self._view))
            buf, where = self._view, "stream_grab_view"
        else:
            assert self._buf is not None
            code = r.stream_grab(self._stream, ctypes.byref(self._buf))
            buf, where = self._buf, "stream_grab"
        if code == r.U3V_ERR_INCOMPLETE:
            raise U3VIncompleteFrame(code, where)
        _check(code, where)
        arr = _frame_to_array(buf)
        return arr.copy() if copy else arr

    def __iter__(self):
        if not self._streaming:
            self.start()
        try:
            while True:
                try:
                    yield self.read_frame()
                except U3VIncompleteFrame:
                    continue   # drop torn/short frames, keep streaming
        except KeyboardInterrupt:
            return

    # ---- last-frame metadata ----
    @property
    def _last_buf(self) -> Optional[r.u3v_buffer_t]:
        """Buffer holding the most recent frame's metadata (view when the ISP
        pipeline is active, otherwise the raw grab buffer)."""
        return self._view if self._pipeline is not None else self._buf

    @property
    def last_frame_status(self) -> int:
        buf = self._last_buf
        return int(buf.status) if buf is not None else -1

    @property
    def last_frame_block_id(self) -> int:
        buf = self._last_buf
        return int(buf.block_id) if buf is not None else 0

    @property
    def last_frame_timestamp_ns(self) -> int:
        buf = self._last_buf
        return int(buf.timestamp) if buf is not None else 0

    # ---- shutdown ----
    def close(self) -> None:
        self.stop()
        # Detach + destroy the ISP pipeline before the stream it is bound to.
        self.disable_color()
        if self._buf is not None:
            with suppress(Exception):
                r.buffer_free(ctypes.byref(self._buf))
            self._buf = None
        if self._stream is not None:
            with suppress(Exception):
                r.stream_destroy(self._stream)
            self._stream = None
        if self._handle:
            with suppress(Exception):
                r.camera_close(self._handle)
            self._handle = r.u3v_camera_p()

    def __del__(self) -> None:
        with suppress(Exception):
            self.close()


__all__ = [
    "Camera",
    "U3VError",
    "U3VIncompleteFrame",
    "list_cameras",
    "__version__",
    # acquisition mode constants
    "ACQ_MODE_CONTINUOUS", "ACQ_MODE_SINGLE_FRAME", "ACQ_MODE_MULTI_FRAME",
    # re-export commonly needed format constants for convenience
    "PFNC_MONO8", "PFNC_MONO10", "PFNC_MONO12", "PFNC_MONO16",
    "PFNC_BAYERGR8", "PFNC_BAYERRG8", "PFNC_BAYERGB8", "PFNC_BAYERBG8",
    "PFNC_BAYERGR10", "PFNC_BAYERRG10", "PFNC_BAYERGB10", "PFNC_BAYERBG10",
    "PFNC_BAYERGR12", "PFNC_BAYERRG12", "PFNC_BAYERGB12", "PFNC_BAYERBG12",
    "PFNC_RGB8",
]

# acquisition mode constants (GenICam semantics)
ACQ_MODE_CONTINUOUS   = r.IMX296_ACQ_MODE_CONTINUOUS
ACQ_MODE_SINGLE_FRAME = r.IMX296_ACQ_MODE_SINGLE
ACQ_MODE_MULTI_FRAME  = r.IMX296_ACQ_MODE_MULTI

# convenience re-exports
PFNC_MONO8     = r.PFNC_MONO8
PFNC_MONO10    = r.PFNC_MONO10
PFNC_MONO12    = r.PFNC_MONO12
PFNC_MONO16    = r.PFNC_MONO16
PFNC_BAYERGR8  = r.PFNC_BAYERGR8
PFNC_BAYERRG8  = r.PFNC_BAYERRG8
PFNC_BAYERGB8  = r.PFNC_BAYERGB8
PFNC_BAYERBG8  = r.PFNC_BAYERBG8
PFNC_BAYERGR10 = r.PFNC_BAYERGR10
PFNC_BAYERRG10 = r.PFNC_BAYERRG10
PFNC_BAYERGB10 = r.PFNC_BAYERGB10
PFNC_BAYERBG10 = r.PFNC_BAYERBG10
PFNC_BAYERGR12 = r.PFNC_BAYERGR12
PFNC_BAYERRG12 = r.PFNC_BAYERRG12
PFNC_BAYERGB12 = r.PFNC_BAYERGB12
PFNC_BAYERBG12 = r.PFNC_BAYERBG12
PFNC_RGB8      = r.PFNC_RGB8
