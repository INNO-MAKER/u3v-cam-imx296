# u3v_cam — Python interface for the U3V Camera SDK

`u3v_cam` is a Python package that wraps the C SDK for USB3 Vision cameras
with the Sony IMX296 sensor.  It uses `ctypes` to call the same shared
library (`u3v_cam.dll` on Windows, `libu3v_cam.so` on Linux) as the C
example programs and the Qt viewer.

The standalone `u3v-sdk-2.2.5.1-python` package bundles the native libraries
for all five supported platforms (Windows x64, Linux x64/ARM64, macOS
arm64/x64) inside `u3v_cam/_libs/<platform>/`, together with the ISP color
plugins under `u3v_cam/_libs/<platform>/plugins/`. Extract, install Python
deps, and run — no build step required.

---

## Requirements

| Component | Version |
|---|---|
| Python  | 3.8 – 3.12 |
| numpy   | required |
| PyQt6 + pyqtgraph | for the live viewer (`pip install u3v_cam[viewer]`) |
| opencv-python | optional; enables `--show` preview in `live_capture.py` |

On Windows you also need:
- WinUSB driver installed for the camera (use Zadig — see
  `WINUSB_DRIVER_INSTALL.md` in the SDK package)
- Microsoft Visual C++ Runtime (already installed on Windows 10/11)

On Linux:
- `libusb-1.0` runtime (`apt install libusb-1.0-0`)
- udev rule for non-root access (`build-tools/pi-build/99-u3v.rules`,
  installed automatically by `install_deps.sh`)

---

## Install

### From the standalone customer package (recommended)

```text
u3v-sdk-2.2.5.1-python/
├── u3v_cam/
│   └── _libs/
│       ├── windows-x64/   u3v_cam.dll + libusb-1.0.dll + plugins/
│       ├── linux-x64/     libu3v_cam.so.2 + plugins/
│       ├── linux-arm64/   libu3v_cam.so.2 + plugins/
│       ├── macos-arm64/   libu3v_cam.2.dylib + plugins/
│       └── macos-x64/     libu3v_cam.2.dylib + plugins/
├── examples/
├── tests/
├── run_basic_capture.{bat,sh}
├── run_live_capture.{bat,sh}
├── run_viewer.{bat,sh}
└── install_deps.{bat,sh}
```

**Windows:**
```bat
unzip u3v-sdk-2.2.5.1-python.zip
cd u3v-sdk-2.2.5.1-python
install_deps.bat                      :: installs numpy + optional viewer/cv2
run_basic_capture.bat                 :: capture 5 frames, save first to .pgm
run_viewer.bat                        :: live PyQt6 viewer
```

**Linux (Ubuntu 22.04 / Pi 5 / Jetson Orin Nano):**
```bash
unzip u3v-sdk-2.2.5.1-python.zip
cd u3v-sdk-2.2.5.1-python
chmod +x *.sh
./install_deps.sh
./run_basic_capture.sh
./run_viewer.sh
```

### Override the library location

If you want to use a different `u3v_cam.dll` / `libu3v_cam.so` than the one
bundled in `_libs/`:

```bash
# Windows
set U3V_CAM_DLL=C:\path\to\u3v_cam.dll

# Linux / macOS
export U3V_CAM_LIB=/path/to/libu3v_cam.so.2
```

### As a regular Python package (development)

```bash
cd u3v-sdk-2.2.5.1-python
pip install -e .          # core
pip install -e .[viewer]  # core + PyQt6 viewer
pip install -e .[opencv]  # core + cv2 preview
```

---

## Quick start

```python
import u3v_cam

with u3v_cam.Camera() as cam:
    print(cam.info)               # {'manufacturer': ..., 'serial': ..., ...}
    cam.exposure_us = 5000        # 5 ms
    cam.gain = 0
    cam.start()
    for _ in range(60):
        frame = cam.read_frame()  # numpy.ndarray, shape (H, W) uint8 for Mono8
        # ... process frame
    cam.stop()
```

The first `read_frame()` auto-starts the stream if `start()` wasn't called
explicitly.  `with`-statement exit closes everything cleanly.

---

## Color capture

Color sensors output a Bayer mosaic. Enable the ISP pipeline with
`cam.enable_color()` and `read_frame()` returns a demosaiced `(H, W, 3)` uint8
RGB image — the same output the Qt viewer produces — instead of the raw
single-channel mosaic.

```python
import u3v_cam

with u3v_cam.Camera() as cam:
    cam.pixel_format = u3v_cam.PFNC_BAYERRG8   # 8-bit Bayer color
    cam.enable_color()                         # load ISP plugins, demosaic on
    cam.start()
    rgb = cam.read_frame()                     # numpy.ndarray (H, W, 3) RGB8
    cam.stop()
```

- `enable_color(plugin_dir=None)` loads the ISP plugins bundled under
  `u3v_cam/_libs/<platform>/plugins/` and attaches them to the stream. It
  returns the number of plugins loaded. Pass `plugin_dir=...` or set the
  `U3V_PLUGIN_DIR` environment variable to load plugins from another location.
- `disable_color()` reverts to raw single-channel capture.
- `color_enabled` reports whether the pipeline is active.
- The demosaic operates on 8-bit Bayer input (`PFNC_BAYERRG8` / `GR8` / `GB8`
  / `BG8`); the Bayer phase is auto-detected from each frame.
- Mono sensors are unaffected — the plugins pass non-Bayer frames through
  unchanged, so `enable_color()` is safe to call on any camera.

Full example: `examples/color_capture.py`.

---

## API at a glance

### Discovery

```python
u3v_cam.list_cameras()
# -> [{'index': 0, 'manufacturer': 'XYZ', 'model': '...', 'serial': '...'}]
```

### `Camera`

| Property | Type | Notes |
|---|---|---|
| `info` | dict | manufacturer, model, serial, firmware, sensor size |
| `width`, `height` | int | live ROI |
| `offset_x`, `offset_y` | int | live ROI offset |
| `pixel_format` | int | use `u3v_cam.PFNC_*` constants |
| `payload_size` | int | bytes per frame (read-only) |
| `exposure_us` | int | exposure in microseconds |
| `gain` | int | sensor gain, 0–480 on IMX296 |
| `frame_rate` | int | target fps |
| `trigger_mode` | bool | trigger enable |
| `temperature` | int | sensor temperature reading |
| `last_frame_status` | int | status of last grab (0 = OK) |
| `last_frame_block_id` | int | monotonic frame counter from the camera |
| `last_frame_timestamp_ns` | int | per-frame timestamp from the camera |
| `color_enabled` | bool | whether the ISP demosaic pipeline is active |

| Method | Purpose |
|---|---|
| `start()`, `stop()` | acquisition control |
| `read_frame(copy=True)` | grab one frame as `np.ndarray` |
| `enable_color(plugin_dir=None)` | load ISP plugins; color frames become `(H, W, 3)` RGB8 |
| `disable_color()` | revert to raw single-channel capture |
| `set_roi(w, h, ox=0, oy=0)` | bulk ROI update with safe ordering |
| `configure_trigger(on, source, activation, selector)` | full trigger config |
| `software_trigger()` | fire one software trigger |
| `set_strobe(duration, delay, pre_delay)` | strobe output config |
| `find_me_led(on=True)` | toggle find-me LED |
| `set_exposure_auto(enable)` | auto-exposure on/off |
| `flush()` | discard pending USB data |
| `read_register(addr)` / `write_register(addr, val)` | low-level register access (advanced) |
| `close()` | release resources (also via `with`) |

### Iteration

```python
for frame in cam:           # auto-start, infinite loop, Ctrl+C ends
    ...
```

---

## Examples

| File | Description |
|---|---|
| `basic_capture.py` | Discover, open, capture 5 frames, save first as PGM |
| `live_capture.py`  | Continuous capture with FPS / dropped statistics; `--show` enables OpenCV preview |
| `trigger_mode.py`  | Software trigger demo with per-trigger latency timing |
| `roi_exposure.py`  | Sweep ROI / exposure / gain combinations |
| `color_capture.py` | Enable the ISP pipeline and save a demosaiced RGB image as PPM |
| `viewer_pyqt.py`   | Full live viewer with PyQt6 + pyqtgraph (sliders, ROI, trigger) |

Run any of them with `python examples/<file>.py`.

---

## Troubleshooting

**`OSError: Failed to locate u3v_cam shared library`**

The Python package didn't find the C library next to itself.  Either:
- copy `u3v_cam.dll` / `libu3v_cam.so.2` into the same folder as
  `u3v_cam/_loader.py`, or
- set `U3V_CAM_DLL` / `U3V_CAM_LIB` to the full path of the library.

**`No camera found`**

- Windows: confirm WinUSB is installed (Device Manager → camera shows
  "WinUSB Devices") — use Zadig if not.
- Linux: confirm udev rules are loaded (`ls /etc/udev/rules.d/` should
  contain `99-u3v.rules`) and replug the camera.

**Color frames look wrong (raw mosaic or tinted)**

- Call `cam.enable_color()` before `start()` so frames come back demosaiced
  as `(H, W, 3)` RGB8. Without it, `read_frame()` returns the raw Bayer
  mosaic.
- Confirm the ISP plugins are present under
  `u3v_cam/_libs/<platform>/plugins/` (or point `U3V_PLUGIN_DIR` at them).
- Use an 8-bit Bayer pixel format (e.g. `cam.pixel_format = u3v_cam.PFNC_BAYERRG8`).

---

## Performance notes

- `read_frame(copy=True)` does one host-side `memcpy`.  At 1456×1088 Mono8
  60 fps that's ~95 MB/s memory bandwidth — negligible on any modern CPU.
- `read_frame(copy=False)` returns a NumPy view into the SDK's reusable
  buffer.  Cheaper, but the data is overwritten on the next `read_frame`.
  Only use when you immediately consume the frame inside the same loop
  iteration.
- The `Camera` class is **not thread-safe**.  If you need concurrent
  control + grab, do control on the same thread that calls
  `read_frame()`, or use a `threading.Lock`.
