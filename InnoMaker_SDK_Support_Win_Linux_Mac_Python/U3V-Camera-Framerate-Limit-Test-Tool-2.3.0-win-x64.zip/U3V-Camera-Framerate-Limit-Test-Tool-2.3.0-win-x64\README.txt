﻿U3V Camera Framerate Limit Test Tool 2.3.0 (Windows x64)
==========================================================

Measures frame loss and data throughput for InnoMaker U3V cameras. Use it to
confirm a camera setting streams every frame without loss, and to find the
highest resolution / frame rate that stays loss-free on your system.

Contents
  loss_bench.exe    the test tool
  u3v_cam.dll       camera runtime (2.3.0)
  libusb-1.0.dll    USB backend

Requirements
  - Windows 10/11 x64
  - Camera(s) on USB3, USB3 Vision interface bound to the WinUSB driver
  - Hardware-trigger tests also need a trigger signal wired to the camera

Set exposure and gain (important)
  Always give an exposure time and a non-zero gain that suit your scene. With
  too little exposure or zero gain the sensor may not deliver usable frames,
  especially under trigger. A good starting point is --exposure 10000 --gain 16.

Quick start (open a terminal in this folder)
  # Free run - camera streams continuously
  loss_bench.exe --width 1024 --height 600 --exposure 10000 --gain 16 --seconds 20

  # Software trigger - the tool issues each trigger (no external signal needed)
  loss_bench.exe --software --width 1024 --height 600 --exposure 10000 --gain 16 --seconds 20

  # External hardware trigger on Line1
  loss_bench.exe --trigger --source 1 --width 1024 --height 600 --exposure 10000 --gain 16 --seconds 20

  loss_bench.exe --help      # all options

Reading the report
  One row per camera plus a TOTAL line:
    Good   frames received complete
    Torn   frames received incomplete (not usable)
    Gap    frames missing from the sequence (dropped)
    Loss%  (Torn + Gap) / expected
    fps    complete frames per second
    MB/s   data rate
  Verdict:
    PASS      every camera received frames and Loss% is 0
    LOSS      one or more frames were torn or dropped
    NO-DATA   a camera received no frames - not a pass (check the connection,
              and for trigger tests the wiring, line number and signal)

Multiple cameras
  By default every camera found is used. Use --cameras N to set the count.
  Connect the cameras to test and run the same command.

Trigger signal (for clean results at higher resolutions)
  Use a hardware-timed trigger source (hardware PWM, a timer, an FPGA or a PLC)
  and keep the trigger rate at or below the camera's frame rate. A trigger made
  by software-toggled GPIO has timing jitter that can drop occasional frames at
  larger frame sizes.

Troubleshooting
  - Found 0 cameras: check the USB3 connection and the WinUSB driver binding;
    close any other application using the camera.
  - Open/access error: another application is holding the camera - close it.
  - Trigger run shows NO-DATA: confirm the signal is on the wired line, try the
    other edge, and keep the trigger rate at or below the frame rate.

Copyright (c) 2026 innomaker All rights reserved
