﻿U3V Camera SDK 2.2.0 — Windows x64
=====================================

Layout
------
  bin/            u3v_viewer.exe and everything it needs at runtime
  bin/plugins/    Official ISP plugins (u3v_isp_color, u3v_ccm, u3v_gamma)
  lib/            u3v_cam.lib — import library for MSVC link
  include/u3v/    Public SDK headers (#include <u3v/u3v_sdk.h>)
  examples/       basic_capture — minimal CLI capture example
  docs/           CHANGELOG.md

Quick start (viewer)
--------------------
  bin\u3v_viewer.exe
  Connect -> select camera -> Preview.
  Color IMX296 users: unfold the "Color / ISP" section for demosaic /
  white-balance / gamma / CCM controls.

Quick start (SDK link)
----------------------
  MSVC command line:
    cl your_app.c /I "path\to\include" "path\to\lib\u3v_cam.lib"
  Deploy u3v_cam.dll + libusb-1.0.dll next to your .exe.

See docs\CHANGELOG.md for the full 2.2.0 change list.
