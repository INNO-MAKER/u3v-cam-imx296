/**
 * u3v_plugin.h - Image Signal Processing plugin ABI (v1)
 *
 * A plugin is a dynamic library (.dll / .so / .dylib) that transforms a
 * captured u3v_buffer_t (raw Bayer / Mono / RGB) into another u3v_buffer_t
 * (demosaic, white balance, gamma, CCM, etc.).
 *
 * ABI contract: this file is the FROZEN interface between libu3v_cam and
 * third-party plugin binaries. Additive changes only. Breaking changes must
 * bump U3V_PLUGIN_ABI_VERSION.
 *
 * The ABI is deliberately C (not C++) to avoid vtable / name-mangling
 * differences across MSVC / GCC / Clang.
 */
#ifndef U3V_PLUGIN_H
#define U3V_PLUGIN_H

#include "u3v_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Plugin export macro: when authoring a plugin binary, define
 * U3V_PLUGIN_BUILD in the plugin's own build to mark the exported
 * entry points. When the host SDK compiles this header (loader/pipeline),
 * the macro collapses to nothing — the prototypes are just declarations,
 * resolved at runtime via dlsym/GetProcAddress.
 */
#if defined(U3V_PLUGIN_BUILD)
    #if defined(_WIN32)
        #define U3V_PLUGIN_EXPORT __declspec(dllexport)
    #else
        #define U3V_PLUGIN_EXPORT __attribute__((visibility("default")))
    #endif
#else
    #define U3V_PLUGIN_EXPORT
#endif

#define U3V_PLUGIN_ABI_VERSION 1

#define U3V_PLUGIN_NAME_MAX  64
#define U3V_PLUGIN_PARAM_MAX 64  /* name len */

/* Order hint: lower runs first. Reserved ranges:
 *     0..99    - reserved
 *   100..199   - demosaic
 *   200..299   - white balance
 *   300..399   - color correction (CCM)
 *   400..499   - tone mapping (gamma / curves)
 *   500..599   - saturation / hue
 *   600..699   - noise reduction / sharpening
 *   700..899   - customer extensions (lens shading, AE/AF, 3D LUT, ...)
 *   900..999   - final format conversion
 * Plugins pick a hint inside their category. Pipeline sorts ascending. */

/* Special PFNC values for accepts/produces. */
#define U3V_PFNC_ANY  0x00000000u  /* plugin accepts/produces any format */

typedef enum {
    U3V_PARAM_TYPE_BOOL      = 0,
    U3V_PARAM_TYPE_INT32     = 1,
    U3V_PARAM_TYPE_UINT32    = 2,
    U3V_PARAM_TYPE_FLOAT     = 3,   /* IEEE754 float */
    U3V_PARAM_TYPE_ENUM      = 4,   /* int32 with enumerated labels */
    U3V_PARAM_TYPE_MATRIX3X3 = 5,   /* 9 floats, row-major */
    U3V_PARAM_TYPE_BUTTON    = 6,   /* stateless action (e.g. "run AWB once") */
} u3v_param_type_t;

/* Parameter descriptor. Points into plugin-owned storage; caller must not
 * free anything. Strings are UTF-8, NUL-terminated. */
typedef struct {
    const char       *name;         /* stable machine-readable id, e.g. "wb.red_gain" */
    const char       *label;        /* short human-readable label */
    const char       *category;     /* logical group, e.g. "WhiteBalance", "Demosaic" */
    const char       *unit;         /* optional unit string, may be NULL */
    u3v_param_type_t  type;
    /* Numeric range (unused for BOOL/BUTTON/MATRIX3X3). For ENUM the range
     * is [0, enum_count-1] and values are int32. */
    double            min_value;
    double            max_value;
    double            default_value;
    /* Enum labels (only for U3V_PARAM_TYPE_ENUM). enum_labels[i] is the
     * label for value i. enum_count is the number of entries. */
    const char *const *enum_labels;
    uint32_t          enum_count;
    uint32_t          flags;        /* reserved, must be 0 */
} u3v_param_t;

/* Plugin self-description. Returned by u3v_plugin_describe(); statically
 * allocated inside the plugin binary. */
typedef struct {
    uint32_t    abi_version;                    /* must equal U3V_PLUGIN_ABI_VERSION */
    const char *name;                           /* stable id, e.g. "u3v_isp_color" */
    const char *vendor;                         /* human-readable vendor string */
    const char *version;                        /* plugin version, semver preferred */
    uint32_t    order_hint;                     /* see reserved ranges above */
    uint32_t    accepts_pfnc;                   /* PFNC accepted, or U3V_PFNC_ANY */
    uint32_t    produces_pfnc;                  /* PFNC produced, or U3V_PFNC_ANY */
    uint32_t    reserved[8];                    /* zero-init; future ABI additions */
} u3v_plugin_info_t;

/* Opaque per-instance state. Multiple instances of the same plugin may
 * exist simultaneously (one per camera / per pipeline). */
typedef struct u3v_plugin_ctx u3v_plugin_ctx_t;

/* ---- Exported entry points ---- */
/* Each plugin binary MUST export exactly these seven C symbols. */

typedef const u3v_plugin_info_t* (*u3v_plugin_describe_fn)(void);
typedef u3v_plugin_ctx_t*        (*u3v_plugin_create_fn)(void);
typedef void                     (*u3v_plugin_destroy_fn)(u3v_plugin_ctx_t *ctx);
typedef u3v_status_t             (*u3v_plugin_process_fn)(u3v_plugin_ctx_t *ctx,
                                                          const u3v_buffer_t *in,
                                                          u3v_buffer_t *out);
typedef uint32_t                 (*u3v_plugin_param_count_fn)(u3v_plugin_ctx_t *ctx);
typedef const u3v_param_t*       (*u3v_plugin_param_get_fn)(u3v_plugin_ctx_t *ctx,
                                                             uint32_t index);
/* Get/set value. Storage for `value` is caller-provided and sized according
 * to param type:
 *   BOOL      -> uint8_t
 *   INT32     -> int32_t
 *   UINT32/ENUM -> uint32_t
 *   FLOAT     -> float
 *   MATRIX3X3 -> float[9]
 *   BUTTON    -> value ignored on set, NULL on get
 */
typedef u3v_status_t             (*u3v_plugin_param_set_fn)(u3v_plugin_ctx_t *ctx,
                                                             const char *name,
                                                             const void *value);
typedef u3v_status_t             (*u3v_plugin_param_get_value_fn)(u3v_plugin_ctx_t *ctx,
                                                                   const char *name,
                                                                   void *value_out);

/* Convenience declarations for authors writing a plugin in this project. */
U3V_PLUGIN_EXPORT const u3v_plugin_info_t* u3v_plugin_describe(void);
U3V_PLUGIN_EXPORT u3v_plugin_ctx_t*        u3v_plugin_create(void);
U3V_PLUGIN_EXPORT void                     u3v_plugin_destroy(u3v_plugin_ctx_t *ctx);
U3V_PLUGIN_EXPORT u3v_status_t             u3v_plugin_process(u3v_plugin_ctx_t *ctx,
                                                              const u3v_buffer_t *in,
                                                              u3v_buffer_t *out);
U3V_PLUGIN_EXPORT uint32_t                 u3v_plugin_param_count(u3v_plugin_ctx_t *ctx);
U3V_PLUGIN_EXPORT const u3v_param_t*       u3v_plugin_param_get(u3v_plugin_ctx_t *ctx,
                                                                 uint32_t index);
U3V_PLUGIN_EXPORT u3v_status_t             u3v_plugin_param_set(u3v_plugin_ctx_t *ctx,
                                                                 const char *name,
                                                                 const void *value);
U3V_PLUGIN_EXPORT u3v_status_t             u3v_plugin_param_get_value(u3v_plugin_ctx_t *ctx,
                                                                       const char *name,
                                                                       void *value_out);

#ifdef __cplusplus
}
#endif

#endif /* U3V_PLUGIN_H */
