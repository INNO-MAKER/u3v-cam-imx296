/**
 * u3v_pipeline.h - ISP plugin pipeline (host-side API)
 *
 * A pipeline owns an ordered list of loaded plugins and applies them to
 * a captured u3v_buffer_t. Zero plugins loaded = pass-through (no work).
 *
 * Threading: a pipeline is single-consumer. Call u3v_pipeline_process()
 * from the stream thread only.
 */
#ifndef U3V_PIPELINE_H
#define U3V_PIPELINE_H

#include "u3v_types.h"
#include "u3v_export.h"
#include "u3v_plugin.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct u3v_pipeline u3v_pipeline_t;

/* Create an empty pipeline. */
U3V_API u3v_status_t u3v_pipeline_create(u3v_pipeline_t **pipe);

/* Destroy pipeline and unload all its plugins. */
U3V_API void         u3v_pipeline_destroy(u3v_pipeline_t *pipe);

/* Load a single plugin binary (.dll / .so / .dylib) by path.
 * On success the pipeline owns the plugin and its instance. */
U3V_API u3v_status_t u3v_pipeline_load(u3v_pipeline_t *pipe, const char *path);

/* Load every plugin binary found in `dir`. Non-plugin files and files that
 * fail to load are skipped silently. Directory scan is non-recursive. */
U3V_API u3v_status_t u3v_pipeline_load_dir(u3v_pipeline_t *pipe, const char *dir);

/* Number of successfully loaded plugins. */
U3V_API uint32_t     u3v_pipeline_plugin_count(const u3v_pipeline_t *pipe);

/* Access a loaded plugin's descriptor for GUI enumeration. Returns NULL if
 * index is out of range. Plugins are sorted by ascending order_hint. */
U3V_API const u3v_plugin_info_t* u3v_pipeline_plugin_info(const u3v_pipeline_t *pipe,
                                                   uint32_t index);

/* Access a loaded plugin's live instance context for parameter I/O.
 * Returns NULL if index is out of range. */
U3V_API u3v_plugin_ctx_t* u3v_pipeline_plugin_ctx(const u3v_pipeline_t *pipe,
                                           uint32_t index);

/* Plugin parameter reflection & I/O, dispatched through the loaded plugin's
 * vtable. `plugin_index` refers to a slot in this pipeline; `name` is the
 * parameter's stable ID.
 *
 * These wrappers exist so hosts (GUI / bindings) do not link against
 * per-plugin symbols — every plugin binary has its own u3v_plugin_param_*
 * copies, so direct linkage is impossible. */
U3V_API uint32_t u3v_pipeline_plugin_param_count(const u3v_pipeline_t *pipe,
                                          uint32_t plugin_index);

U3V_API const u3v_param_t* u3v_pipeline_plugin_param_get(const u3v_pipeline_t *pipe,
                                                  uint32_t plugin_index,
                                                  uint32_t param_index);

U3V_API u3v_status_t u3v_pipeline_plugin_param_set(u3v_pipeline_t *pipe,
                                            uint32_t plugin_index,
                                            const char *name,
                                            const void *value);

U3V_API u3v_status_t u3v_pipeline_plugin_param_get_value(u3v_pipeline_t *pipe,
                                                  uint32_t plugin_index,
                                                  const char *name,
                                                  void *value_out);

/* Enable/disable a plugin without unloading it. Disabled plugins are skipped
 * during process(). Newly loaded plugins default to enabled. */
U3V_API u3v_status_t u3v_pipeline_set_enabled(u3v_pipeline_t *pipe, uint32_t index,
                                       int enabled);
U3V_API int          u3v_pipeline_is_enabled(const u3v_pipeline_t *pipe, uint32_t index);

/* Run the pipeline over `in`, producing `out`.
 *
 * Behaviour:
 *   - 0 loaded/enabled plugins: out receives a shallow alias of in
 *     (out->data == in->data, out->size == in->size). Caller MUST NOT free
 *     out->data. This is the zero-regression path.
 *   - >0 plugins: out points to an internally-managed scratch buffer that
 *     survives until the next u3v_pipeline_process() call or destroy.
 *     Metadata (width/height/pixel_format/timestamp/block_id) is propagated
 *     and updated by each stage.
 *
 * If any plugin returns non-U3V_OK, the pipeline aborts and returns that
 * status; `out` contents are undefined. */
U3V_API u3v_status_t u3v_pipeline_process(u3v_pipeline_t *pipe,
                                   const u3v_buffer_t *in,
                                   u3v_buffer_t *out);

#ifdef __cplusplus
}
#endif

#endif /* U3V_PIPELINE_H */
