/**
 * u3v_types.h - Public SDK types: status codes, pixel formats, buffers.
 */
#ifndef U3V_TYPES_H
#define U3V_TYPES_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* --------------------------------------------------------------------------
 * Error codes
 * ----------------------------------------------------------------------- */
typedef enum {
    U3V_OK                    =  0,
    U3V_ERR_INVALID_PARAM     = -1,
    U3V_ERR_NO_DEVICE         = -2,
    U3V_ERR_USB_OPEN          = -3,
    U3V_ERR_USB_IO            = -4,
    U3V_ERR_TIMEOUT           = -5,
    U3V_ERR_PROTOCOL          = -6,
    U3V_ERR_NO_MEMORY         = -7,
    U3V_ERR_NOT_CONNECTED     = -8,
    U3V_ERR_BUSY              = -9,
    U3V_ERR_ABORTED           = -10,
    U3V_ERR_BUFFER_TOO_SMALL  = -11,
    U3V_ERR_STREAM            = -12,
    U3V_ERR_INCOMPLETE        = -13,
} u3v_status_t;

static inline const char* u3v_status_str(u3v_status_t s) {
    switch (s) {
    case U3V_OK:                   return "OK";
    case U3V_ERR_INVALID_PARAM:    return "Invalid parameter";
    case U3V_ERR_NO_DEVICE:        return "No device found";
    case U3V_ERR_USB_OPEN:         return "USB open failed";
    case U3V_ERR_USB_IO:           return "USB I/O error";
    case U3V_ERR_TIMEOUT:          return "Timeout";
    case U3V_ERR_PROTOCOL:         return "Protocol error";
    case U3V_ERR_NO_MEMORY:        return "Out of memory";
    case U3V_ERR_NOT_CONNECTED:    return "Not connected";
    case U3V_ERR_BUSY:             return "Device busy";
    case U3V_ERR_ABORTED:          return "Aborted";
    case U3V_ERR_BUFFER_TOO_SMALL: return "Buffer too small";
    case U3V_ERR_STREAM:           return "Stream error";
    case U3V_ERR_INCOMPLETE:       return "Incomplete frame";
    default:                       return "Unknown error";
    }
}

/* --------------------------------------------------------------------------
 * USB3 Vision class identifiers
 * ----------------------------------------------------------------------- */
#define U3V_INTERFACE_CLASS     0xEF
#define U3V_INTERFACE_SUBCLASS  0x05
#define U3V_INTERFACE_PROTOCOL  0x00

/* USB3 Vision interface IDs (by convention) */
#define U3V_CONTROL_INTERFACE   0
#define U3V_EVENT_INTERFACE     1
#define U3V_STREAM_INTERFACE    2




/* --------------------------------------------------------------------------
 * GenICam standard enum values (AcquisitionMode, TriggerMode, ...)
 * ----------------------------------------------------------------------- */
#define U3V_ACQ_MODE_CONTINUOUS         0
#define U3V_ACQ_MODE_SINGLE_FRAME       1
#define U3V_ACQ_MODE_MULTI_FRAME        2

#define U3V_TRIGGER_MODE_OFF            0
#define U3V_TRIGGER_MODE_ON             1

/* TriggerSelector — which acquisition stage the trigger drives */
#define U3V_TRIGGER_SELECTOR_ACQUISITION_START  1
#define U3V_TRIGGER_SELECTOR_FRAME_START        2

/* TriggerSource — signal that fires the trigger */
#define U3V_TRIGGER_SOURCE_LINE0        0
#define U3V_TRIGGER_SOURCE_LINE1        1
#define U3V_TRIGGER_SOURCE_LINE2        2
#define U3V_TRIGGER_SOURCE_LINE3        3
#define U3V_TRIGGER_SOURCE_SOFTWARE     4

/* TriggerActivation — signal edge that the trigger responds to */
#define U3V_TRIGGER_ACTIVATION_FALLING_EDGE     2
#define U3V_TRIGGER_ACTIVATION_RISING_EDGE      3

/* ExposureAuto — automatic exposure control */
#define U3V_EXPOSURE_AUTO_OFF           0
#define U3V_EXPOSURE_AUTO_ONCE          1
#define U3V_EXPOSURE_AUTO_CONTINUOUS    2

/* --------------------------------------------------------------------------
 * GenICam Pixel Format Naming Convention (PFNC) - common formats
 * ----------------------------------------------------------------------- */
#define PFNC_MONO8              0x01080001
#define PFNC_MONO10             0x01100003
#define PFNC_MONO10_PACKED      0x010C0004
#define PFNC_MONO12             0x01100005
#define PFNC_MONO12_PACKED      0x010C0006
#define PFNC_MONO16             0x01100007
#define PFNC_BAYERGR8           0x01080008
#define PFNC_BAYERRG8           0x01080009
#define PFNC_BAYERGB8           0x0108000A
#define PFNC_BAYERBG8           0x0108000B
#define PFNC_BAYERGR10          0x0110000C
#define PFNC_BAYERRG10          0x0110000D
#define PFNC_BAYERGB10          0x0110000E
#define PFNC_BAYERBG10          0x0110000F
#define PFNC_BAYERGR12          0x01100010
#define PFNC_BAYERRG12          0x01100011
#define PFNC_BAYERGB12          0x01100012
#define PFNC_BAYERBG12          0x01100013
#define PFNC_YUV422_8           0x02100032
#define PFNC_RGB8               0x02180014

/* --------------------------------------------------------------------------
 * Utility types
 * ----------------------------------------------------------------------- */
typedef struct {
    uint16_t vendor_id;
    uint16_t product_id;
    char     serial[64];
    char     model[64];
    char     manufacturer[64];
    int      device_index;       /* internal enumeration index */
} u3v_device_info_t;

/* Forward declarations of opaque handles used across the public API. */
typedef struct u3v_camera u3v_camera_t;
typedef struct u3v_stream u3v_stream_t;

/* Image buffer */
typedef struct {
    uint8_t  *data;
    uint32_t  size;             /* allocated buffer size */
    uint32_t  received_size;    /* actual data received */
    uint32_t  width;
    uint32_t  height;
    uint32_t  pixel_format;
    uint64_t  timestamp;
    uint64_t  block_id;
    uint16_t  status;           /* trailer status: 0 = success */
} u3v_buffer_t;

/* Callback for asynchronous image delivery */
typedef void (*u3v_frame_callback_t)(u3v_buffer_t *buffer, void *user_data);

#ifdef __cplusplus
}
#endif

#endif /* U3V_TYPES_H */
