/**
 * multi_frame_capture.c - USB3 Vision Camera SDK example
 *
 * Demonstrates MultiFrame acquisition mode: the camera captures a fixed
 * number of frames set by AcquisitionFrameCount and then stops on its own.
 * Useful for burst capture, synchronized N-frame sequences, or any workflow
 * where you know the exact frame count in advance.
 *
 * Build (CMake):
 *   cmake --build build --target multi_frame_capture
 */
#include <stdio.h>
#include <stdlib.h>
#include <u3v/u3v_sdk.h>

int main(int argc, char *argv[]) {
    u3v_status_t st;
    uint32_t frame_count = 5;

    if (argc > 1) {
        int n = atoi(argv[1]);
        if (n > 0) frame_count = (uint32_t)n;
    }

    printf("=== U3V Camera SDK - MultiFrame Capture (%u frames) ===\n\n",
           frame_count);

    st = u3v_sdk_init();
    if (st != U3V_OK) {
        fprintf(stderr, "SDK init failed: %s\n", u3v_status_str(st));
        return 1;
    }

    u3v_device_info_t devices[4];
    int count = u3v_discover(devices, 4);
    if (count == 0) {
        fprintf(stderr, "No camera found.\n");
        u3v_sdk_shutdown();
        return 1;
    }

    u3v_camera_t *cam = NULL;
    st = u3v_camera_open(&cam, 0);
    if (st != U3V_OK) {
        fprintf(stderr, "Camera open failed: %s\n", u3v_status_str(st));
        u3v_sdk_shutdown();
        return 1;
    }

    const u3v_cam_info_t *info = u3v_camera_get_info(cam);
    printf("Connected: %s %s (S/N: %s)\n\n",
           info->manufacturer, info->model, info->serial);

    /* Configure image parameters */
    u3v_camera_set_width(cam, info->width_max);
    u3v_camera_set_height(cam, info->height_max);
    u3v_camera_set_pixel_format(cam, PFNC_MONO8);
    u3v_camera_set_exposure(cam, 10000);
    u3v_camera_set_gain(cam, 0);

    /* Switch to MultiFrame mode and set how many frames to acquire */
    st = u3v_camera_set_acq_mode(cam, U3V_ACQ_MODE_MULTI_FRAME);
    if (st != U3V_OK) {
        fprintf(stderr, "Set MultiFrame mode failed: %s\n", u3v_status_str(st));
        u3v_camera_close(cam);
        u3v_sdk_shutdown();
        return 1;
    }

    st = u3v_camera_set_frame_count(cam, frame_count);
    if (st != U3V_OK) {
        fprintf(stderr, "Set frame count failed: %s\n", u3v_status_str(st));
        u3v_camera_close(cam);
        u3v_sdk_shutdown();
        return 1;
    }

    u3v_stream_t *stream = NULL;
    u3v_stream_config_t scfg = { .num_buffers = 4, .timeout_ms = 5000,
                                  .transfer_size = 0 };
    st = u3v_stream_create(&stream, cam, &scfg);
    if (st != U3V_OK) {
        fprintf(stderr, "Stream create failed: %s\n", u3v_status_str(st));
        u3v_camera_close(cam);
        u3v_sdk_shutdown();
        return 1;
    }

    uint32_t payload = 0;
    u3v_camera_get_payload_size(cam, &payload);
    u3v_buffer_t buf;
    uint32_t buf_size = payload > 0 ? payload : (info->width_max * info->height_max);
    st = u3v_buffer_alloc(&buf, buf_size);
    if (st != U3V_OK) {
        fprintf(stderr, "Buffer alloc failed: %s\n", u3v_status_str(st));
        u3v_stream_destroy(stream);
        u3v_camera_close(cam);
        u3v_sdk_shutdown();
        return 1;
    }

    printf("Starting acquisition...\n");
    st = u3v_camera_start(cam);
    if (st != U3V_OK) {
        fprintf(stderr, "Acquisition start failed: %s\n", u3v_status_str(st));
        u3v_buffer_free(&buf);
        u3v_stream_destroy(stream);
        u3v_camera_close(cam);
        u3v_sdk_shutdown();
        return 1;
    }

    /* Grab exactly frame_count frames — camera stops on its own in
     * MultiFrame mode once the count is reached. */
    uint32_t grabbed = 0;
    for (uint32_t i = 0; i < frame_count; i++) {
        st = u3v_stream_grab(stream, &buf);
        if (st != U3V_OK) {
            fprintf(stderr, "Frame %u grab failed: %s\n", i, u3v_status_str(st));
            continue;
        }
        grabbed++;
        printf("Frame %u: %ux%u, %u bytes, status=%u\n",
               i, buf.width, buf.height, buf.received_size, buf.status);

        if (i == 0) {
            const char *outfile = "multiframe_0.pgm";
            if (u3v_buffer_save(&buf, outfile) == U3V_OK)
                printf("  -> Saved to %s\n", outfile);
        }
    }

    printf("\nGrabbed %u / %u frames.\n", grabbed, frame_count);

    u3v_camera_stop(cam);
    u3v_buffer_free(&buf);
    u3v_stream_destroy(stream);
    u3v_camera_close(cam);
    u3v_sdk_shutdown();

    printf("Done.\n");
    return 0;
}
